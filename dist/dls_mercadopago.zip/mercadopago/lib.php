<?php
// The library functions used by your payment plugin